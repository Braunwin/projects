/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vut;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author st
 */
public class StudentTest{
/**
 * 
 */
    @Test
    public void  testSetNameMutator(){
        // Create object of a class you are testing
        Student objStudent = new Student("Bofelo", 34,75,66);
        objStudent.setName("Rabotapi");
       assertEquals("Rabotapi",objStudent.getName());
    
        
    
    
    }
    @Test(expected = IllegalArgumentException.class)
    
    public void  testSetInavlidtMutator(){
        //Create  an object o fthe class you are testing 
        
        Student objStudent = new Student("Bofelo", 34,75,66);
        objStudent.setName("Ra");
       assertEquals("Ra",objStudent.getName());
    }
    
    public void TestSetTest1Mutator(){
         Student objStudent = new Student("Bofelo", 34,75,66);
         objStudent.setTest1(35);
         assertEquals(35, objStudent.getTest1(),0);
    
   
    }
    
    
    
            
            

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {
}
