package vut;

/**
 * The class stores the name of a student and 3 test marks
 *
 * @author me
 */
public class Student {

    private String name;
    private double test1, test2, test3;

    public Student() {
        this("Sihlahla", 0, 0, 0);
    }

    public Student(String name, double test1, double test2, double test3) {
        setName(name);
        setTest1(test1);
        setTest2(test2);
        setTest3(test3);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.length() >= 3) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("The Student name:"+ name + " is too shot");
        }
    }

    public void setTest1(double test1) {
        if (test1 >= 0 && test1 <= 100) {
            this.test1 = test1;
        } else {
            throw new IllegalArgumentException("The test score must be in the range 0-100");
        }
    }

    public void setTest2(double test2) {
        if (test2 >= 0 && test2 <= 100) {
            this.test2 = test2;
        } else {
            throw new IllegalArgumentException("The test score must be in the range 0-100");
        }
    }

    public void setTest3(double test3) {
        if (test3 >= 0 && test3 <= 100) {
            this.test3 = test3;
        } else {
            throw new IllegalArgumentException("The test score must be in the range 0-100");
        }
    }

    public double getTest1() {
        return test1;
    }

    public double getTest2() {
        return test2;
    }

    public double getTest3() {
        return test3;
    }

    @Override
    public String toString() {
        return "Student Name: " + name + "\nTest1: " + test1 + "\nTest2: " + test2 + "\nTest3: " + test3;
    }

}/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    

